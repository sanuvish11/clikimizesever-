module.exports = {
  secret: "duda-secret-key"
};
