const express = require('express');
const config = require("../config/auth.config");
var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");
const router = express.Router();
var db = require("../models");

var Transaction = db.transaction;
var PackageDetail = db.packagedetail;
var User = db.user;
const Op = db.Sequelize.Op;
const stripe = require('stripe')('sk_test_4eC39HqLyjWDarjtT1zdp7dc');

router.post('/payment', (req, res) => {
    Transaction.create({
        tblUserId: req.body.tblUserId,
        Amount: req.body.Amount,
        paymentMode: req.body.paymentMode,
        paymenDate: Date.now(),
        status: req.body.status,
        transactionRef: req.body.transactionRef,
        transactionId: req.body.transactionId
    }).then((transaction) => {
        
        return stripe.charges.create({
            amount: 2500,
            description: 'Web Development Product',
            currency: 'INR',
            customer: transaction.id
        }).then((charges) => {
            res.json({
                status: 1,
                message: "Paymnet done!"
            })
        }).catch(err => {
            res.send({
                err: err,
                status: 5,
                message: "unble to proceess"
            });
        });


    })

})
//POST ROUTE
//transaction deatil save 
router.post('/save', (req, res) => {
    // Transaction.findOne({
    //     // where: {
    //     //   tblUserId: req.body.tblUserId
    //     // }, where: {
    //     //   tblPackageDetailId: req.body.tblPackageDetailId
    //     // }
    // }).then(trans => {
    //     if (trans) {
    //         res.status(400).send({
    //             message: "Failed! Package already exits!"
    //         });
    //         return;
    //     }
    //     else {
    Transaction.create({
        tblUserId: req.body.tblUserId,
        paymentMode: req.body.paymentMode,
        paymenDate: req.body.paymenDate,
        status: req.body.status,
        transactionRef: req.body.transactionRef,
        transactionId: req.body.transactionId
    }).then(transaction => {
        res.json({
            status: 1,
            message: "record insert successfully"
        })
    })
        .catch(err => {
            res.send({
                err: err,
                status: 5,
                message: "unble to proceess"
            });
        });
})
// })
//})


//update package detail by id(1)
router.post('/update/:id', (req, res) => {
    const id = req.body.id;
    Transaction.update(req.body, {
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    status: 1,
                    message: "transition updated successfully."
                });
            } else {
                res.send({
                    status: 0,
                    message: `Cannot update transition with id=${id}. Maybe transition was not found or req.body is empty!`
                });
            }
        }).catch(err => {
            res.send({
                err: err,
                status: 5,
                message: "unable to proccess=" + id
            });
        });
})

//get routes
//get all record form userpackage with join packagedetai and user detail
router.get('/getall', (req, res) => {
    Transaction.findAll({
        include: [{
            model: User,
            required: true,
        }]
    })
        .then(userpackage => {
            if (userpackage.length != 0) {
                res.json({
                    userpackage: userpackage,
                    status: 1,
                })
            }
            else {
                res.json({
                    status: 4,
                    message: "No Record Found"
                })
            }

        }).catch(err => {
            res.send({
                err: err,
                status: 5,
                message: "unable to proccess"
            });
        });
})
//delete routes
//delete record by id
router.delete('/delete/:id', (req, res) => {
    const id = req.params.id;
    Transaction.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    status: 1,
                    message: "Transaction was deleted successfully!"
                });
            } else {
                res.send({
                    status: 0,
                    message: `Cannot delete Transaction with id=${id}. Maybe Transaction was not found!`
                });
            }
        })
        .catch(err => {
            res.send({
                err: err,
                status: 5,
                message: "unable to proccess=" + id
            });
        });
});

module.exports = router;