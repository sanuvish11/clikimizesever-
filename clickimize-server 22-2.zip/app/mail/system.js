var system = {
    mail: {
        service: 'gmail',
        Port: 465,
        secure: true,
        auth: {
            user: 'sanuvish11@gmail.com',
            password: 'Shanu@275'
        }
    }
}

module.exports = system;