const express = require("express");
const app = express();
const adminCtl = require("../controllers/admin.controller");
const siteCtl = require("../controllers/sitesetting.controller");
const userCtl = require("../controllers/user.controller");
const packageCtl = require("../controllers/package.controller");
const userpackageCtl = require("../controllers/userpackage.controller");
const packagedetailCtl = require("../controllers/packagedetail.controller");
const mananagcontentCtl = require("../controllers/mananagcontent.controller");
const emailtemplateCtl = require("../controllers/emailtemplate.controller");
const abusekeywordCtl = require("../controllers/abusekeyword.controller");
const transactionCtl = require("../controllers/transaction.controller");
const roleCtl = require("../controllers/role.controller");
const packageTypeCtl = require("../controllers/packageType.controller");
const blogCtl = require("../controllers/blog.controller");
const newsletterCtl = require("../controllers/newsletter.contoller");
const contactusCtl = require("../controllers/contactus.controller");
const likeCtl = require("../controllers/like.contoller");
const privatemessageCtl = require("../controllers/privatemessage.contoller");

const { authJwt } = require("../middleware");
module.exports = function(app) {
    app.use(function(req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    // [authJwt.verifyToken],
    app.use('/auth', adminCtl);
    app.use('/settings', siteCtl);
    app.use('/user', userCtl);
    app.use('/packagetype', packageTypeCtl);
    // app.use('/package', packageCtl);
    app.use('/packagedetail', packagedetailCtl);
    app.use('/manage', mananagcontentCtl);
    app.use('/email', emailtemplateCtl);
    app.use('/abuse', abusekeywordCtl);
    app.use('/blog', blogCtl);
    app.use('/like', likeCtl);
    app.use('/newslatter', newsletterCtl);
    app.use('/contactus', contactusCtl);
    app.use('/userpackage', userpackageCtl);
    app.use('/transaction', transactionCtl);
    app.use('/privateMessage', privatemessageCtl);
    app.use('/role', roleCtl);
    app.use('/logo', express.static('public/logo'));
    app.use('/favi', express.static('public/favicon'));
    app.use('/profile', express.static('public/profile'));
    app.use('/blogImage', express.static('public/blogImage'));
};