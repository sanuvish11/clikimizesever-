module.exports = (sequelize, Sequelize) => {
    const ManageContent = sequelize.define("tbl_manage_content", {
        tblAdminId: {
            type: Sequelize.INTEGER,
        },
        pageTitle: {
            type: Sequelize.STRING
        },
        pageSlug: {
            type: Sequelize.STRING
        },
        metaKeyword: {
            type: Sequelize.STRING
        },
        metaDescription: {
            type: Sequelize.STRING
        },
        linkType: {
            type: Sequelize.STRING
        },
        pageDescription: {
            type: Sequelize.INTEGER
        },
        status: {
            type: Sequelize.STRING
        },
        url: {
            type: Sequelize.STRING
        }

    });
    return ManageContent;
};
