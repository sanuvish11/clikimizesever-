<!-- status code -->

0 fail 
1 success
2 duplicate
3 invalid data
4 record not found
5 unble to proceess


<!-- server config -->
port :8080

<!-- database configration -->

  HOST=localhost
  USER=root
  PASSWOR= root
  DB=CLICKIMIZE
  dialect=mysql
  port:3306

<!-- dependancy name with version -->

npm install bcryptjs  2.4.3

npm install body-parser 1.19.0

npm install buffer 5.6.0

npm install cors 2.8.5

npm install express 4.17.1

npm install fs 0.0.1-security

npm install jsonwebtoken  8.5.1

npm install jwt-decode 3.1.2

npm install multer 1.4.2

npm install mysql2 2.1.0

npm install nodemailer 6.4.17
 
npm install nodemon  2.0.7

npm install path 0.12.7

npm install sequelize ^5.21.3

npm install url 0.11.0